#include <stdio.h>

int main(void){


        //double cali;
        int asked_cali;
        printf("Ingrese su calificación: ");
        scanf("%d", &asked_cali);
        //cali = (double)asked_cali;

        if( asked_cali > 10){
                printf("Error\n");
        }else if( asked_cali < 0){
                printf("Error\n");
        }else{
                switch(asked_cali){
                        case 10:
                                printf("Excelente\n");
                                break;
                        case 9:
                                printf("Muy bien\n");
                                break;
                        case 8:
                                printf("Bien\n");
                                break;
                        case 7:
 				printf("Regular\n");
                                break;
                        default:
                                printf("No acreditado\n");
                }
        }
        return 0;
}
