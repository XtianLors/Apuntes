/*
  Name: actividad7.c
  Copyright: CC BY 4.0
  Author: CristianD. L�pezR.
  Date: 13/08/23 20:21
  Description: Construir un programa que admita cadenas y permita al 
  usuario seleccionar si desea ver la cadena en may�sculas o min�sculas.
*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

// Cambiar cadena de caracteres a min�scula.
void toLowerCase(char *str) {
     int i;
    for (i = 0; str[i]; i++) {
        str[i] = tolower(str[i]);
    }
}

// Cambiar cadena de caracteres a may�sculas.
void toUpperCase(char *str) {
     int i;
    for (i = 0; str[i]; i++) {
        str[i] = toupper(str[i]);
    }
}

int main() {
    // Declarar variables y funciones prototipo.
    void toLowerCase(char *str);
    void toUpperCase(char *str);
    char inputString[100];
    int choice;
    
    // Inputs.
    printf("Introduzca la cadena: ");
    scanf(" %[^\n]", inputString);

    printf("Escoja una opci�n:\n");
    printf("1. Imprimir en min�sculas.\n");
    printf("2. Imprimir en may�sculas.\n");
    scanf("%d", &choice);

    // Salidas de caracteres.
    switch (choice) {
        case 1:
            toLowerCase(inputString);
            printf("Cadena en min�sculas: %s\n", inputString);
            getchar();
            break;
        case 2:
            toUpperCase(inputString);
            printf("Cadena en may�sculas: %s\n", inputString);
            getchar();
            break;
        default:
            printf("Opci�n no v�lida.\n");
            getchar();
            break;
    }
    // Para visualizar la salida.
    getchar();

    return 0;
}
